-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7c207.p.ssafy.io    Database: 93pro
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `route_type` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `route_name` varchar(45) COLLATE utf8mb4_bin DEFAULT NULL,
  `done` varchar(45) COLLATE utf8mb4_bin DEFAULT 'ready',
  `actual_start_time` time DEFAULT NULL,
  `scheduled_start_time` time DEFAULT NULL,
  `date` date NOT NULL,
  `region` varchar(45) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `route_user_id_idx` (`user_id`),
  CONSTRAINT `route_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (1,2,'lunch','전남대학교','1','11:37:46','12:10:00','2022-11-18','GWANGJU'),(2,2,'dinner','전남대학교','1','11:32:11','17:30:00','2022-11-18','GWANGJU'),(3,1,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-18','GWANGJU'),(4,1,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-18','GWANGJU'),(5,3,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-18','GWANGJU'),(6,3,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-18','GWANGJU'),(7,4,'lunch','연세대학교','0',NULL,'12:10:00','2022-11-18','SEOUL'),(8,4,'dinner','연세대학교','0',NULL,'17:30:00','2022-11-18','SEOUL'),(9,5,'lunch','전남대학교','0','17:23:39','12:10:00','2022-11-18','GWANGJU'),(10,8,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-18','GWANGJU'),(11,8,'dinner','광주과학기술원','1','20:56:21','17:30:00','2022-11-18','GWANGJU'),(12,5,'dinner','전남대학교','0','16:49:40','17:30:00','2022-11-18','GWANGJU'),(13,16,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-18','GWANGJU'),(14,16,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-18','GWANGJU'),(15,15,'lunch','전남대학교','1','20:52:00','12:10:00','2022-11-18','GWANGJU'),(16,17,'dinner','KBI하남','1','00:01:23','23:30:00','2022-11-17','GWANGJU'),(17,17,'dinner','KBI하남','1','23:04:14','23:30:00','2022-11-18','GWANGJU'),(18,2,'lunch','전남대학교','1','11:37:46','12:10:00','2022-11-17','GWANGJU'),(19,2,'dinner','전남대학교','1','11:32:11','17:30:00','2022-11-17','GWANGJU'),(20,1,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-17','GWANGJU'),(21,1,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-17','GWANGJU'),(22,3,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-17','GWANGJU'),(23,3,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-17','GWANGJU'),(24,4,'lunch','연세대학교','0',NULL,'12:10:00','2022-11-17','SEOUL'),(25,4,'dinner','연세대학교','0',NULL,'17:30:00','2022-11-17','SEOUL'),(26,5,'lunch','전남대학교','0','21:41:54','12:10:00','2022-11-17','GWANGJU'),(27,8,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-17','GWANGJU'),(28,8,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-17','GWANGJU'),(29,5,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-17','GWANGJU'),(30,16,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-17','GWANGJU'),(31,16,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-17','GWANGJU'),(32,15,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-17','GWANGJU'),(33,2,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-21','GWANGJU'),(34,2,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-21','GWANGJU'),(35,1,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-21','GWANGJU'),(36,1,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-21','GWANGJU'),(37,3,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-21','GWANGJU'),(38,3,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-21','GWANGJU'),(39,4,'lunch','연세대학교','0',NULL,'12:10:00','2022-11-21','SEOUL'),(40,4,'dinner','연세대학교','0',NULL,'17:30:00','2022-11-21','SEOUL'),(41,5,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-21','GWANGJU'),(42,8,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-21','GWANGJU'),(43,8,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-21','GWANGJU'),(44,5,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-21','GWANGJU'),(45,16,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-21','GWANGJU'),(46,16,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-21','GWANGJU'),(47,15,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-21','GWANGJU'),(48,17,'lunch','KBI하남','1','11:02:22','12:10:00','2022-11-19','GWANGJU'),(49,17,'dinner','KBI하남','1','11:33:24','17:30:00','2022-11-19','GWANGJU'),(50,2,'lunch','전남대학교','0','23:33:34','12:10:00','2022-11-19','GWANGJU'),(51,2,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-19','GWANGJU'),(52,1,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-19','GWANGJU'),(53,1,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-19','GWANGJU'),(54,3,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-19','GWANGJU'),(55,3,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-19','GWANGJU'),(56,4,'lunch','연세대학교','0',NULL,'12:10:00','2022-11-19','SEOUL'),(57,4,'dinner','연세대학교','0',NULL,'17:30:00','2022-11-19','SEOUL'),(58,5,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-19','GWANGJU'),(59,8,'lunch','광주과학기술원','1','14:20:30','12:10:00','2022-11-19','GWANGJU'),(60,8,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-19','GWANGJU'),(61,5,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-19','GWANGJU'),(62,16,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-19','GWANGJU'),(63,16,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-19','GWANGJU'),(64,15,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-19','GWANGJU'),(65,2,'lunch','전남대학교','1','01:51:49','12:10:00','2022-11-20','GWANGJU'),(66,2,'dinner','전남대학교','0','03:07:29','17:30:00','2022-11-20','GWANGJU'),(67,1,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-20','GWANGJU'),(68,1,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-20','GWANGJU'),(69,3,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-20','GWANGJU'),(70,3,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-20','GWANGJU'),(71,4,'lunch','연세대학교','0',NULL,'12:10:00','2022-11-20','SEOUL'),(72,4,'dinner','연세대학교','0',NULL,'17:30:00','2022-11-20','SEOUL'),(73,5,'lunch','전남대학교','0','14:03:50','12:10:00','2022-11-20','GWANGJU'),(74,8,'lunch','광주과학기술원','0',NULL,'12:10:00','2022-11-20','GWANGJU'),(75,8,'dinner','광주과학기술원','0',NULL,'17:30:00','2022-11-20','GWANGJU'),(76,5,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-20','GWANGJU'),(77,16,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-20','GWANGJU'),(78,16,'dinner','전남대학교','0',NULL,'17:30:00','2022-11-20','GWANGJU'),(79,15,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-20','GWANGJU'),(80,17,'lunch','전남대학교','0',NULL,'12:10:00','2022-11-19','GWANGJU'),(82,17,'lunch','KBI하남','0',NULL,'12:10:00','2022-11-20','GWANGJU'),(83,17,'dinner','KBI하남','0','10:08:00','17:30:00','2022-11-20','GWANGJU'),(84,17,'lunch','삼성교육장','1','17:24:50','11:00:00','2022-11-20','GWANGJU'),(85,17,'lunch','삼성교육장','0',NULL,'09:35:00','2022-11-21','GWANGJU'),(86,17,'lunch','삼성교육장','1','17:15:40','13:00:00','2022-11-20','GWANGJU');
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-21  0:00:04
