-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7c207.p.ssafy.io    Database: 93pro
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ordermenu`
--

DROP TABLE IF EXISTS `ordermenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordermenu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `menu` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `number` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_menu_order_id_idx` (`order_id`),
  CONSTRAINT `order_menu_order_id` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordermenu`
--

LOCK TABLES `ordermenu` WRITE;
/*!40000 ALTER TABLE `ordermenu` DISABLE KEYS */;
INSERT INTO `ordermenu` VALUES (1,1,'자부심초밥세트(10P)',1),(2,1,'진심초밥세트(10P)',2),(3,2,'제주흑돼지 600g',1),(4,3,'제주흑돼지 600g',2),(5,3,'제주백돼지 400g',1),(6,4,'참숯양념돼지갈비(2인)',1),(7,5,'참숯양념돼지갈비(4인)',1),(8,6,'참숯양념돼지갈비(3인)',1),(9,7,'기본메뉴',2),(10,7,'치즈메뉴',3),(11,8,'기본메뉴',3),(12,8,'스페셜메뉴',3),(13,9,'봉구스밥버거',3),(14,9,'햄밥버거',2),(15,10,'떡갈비밥버거',6),(16,11,'치즈돈가스도시락',1),(17,11,'돈가스도시락',3),(18,12,'돈가스도시락',4),(19,12,'옛날치즈돈가스',3),(20,13,'치즈돈가스도시락',4),(21,14,'야들야들대패덮밥',3),(22,15,'단짠단짠갈비덮밥',2),(23,16,'야들야들대패덮밥',1),(24,17,'마라탕',1),(25,18,'마라탕',2),(26,18,'꿔바로우',1),(27,19,'하루가혼밥세트',2),(28,20,'참치김밥',3),(29,21,'킹부각치킨',2),(30,21,'후라이드치킨',1),(31,22,'양념치킨',1),(32,23,'스페셜초밥',1),(33,23,'모듬초밥',2),(34,24,'우삼겹덮밥',3),(35,24,'돈까스도시락',2),(36,24,'제육도시락',4),(37,25,'된장찌개세트',2),(38,25,'김치볶음밥',3),(39,26,'소코아카레',2),(40,26,'냉우동연어샐러드',3),(41,27,'소고기쌀국수',1),(42,27,'얼큰쌀국수',2),(43,28,'소고기쌀국수',2),(44,29,'얼큰쌀국수',3),(45,30,'소고기쌀국수',2),(46,31,'떡튀세트',2),(47,31,'매운돈까스',1),(48,32,'떡튀세트',4),(49,33,'통닭발',2),(50,33,'무뼈닭발',1),(51,33,'치킨',1),(52,34,'후라이드치킨',2),(53,34,'양념치킨',1),(54,35,'후라이드치킨',2),(55,36,'파닭치킨',2),(56,36,'양념치킨',2),(57,37,'반반치킨',1),(58,37,'파닭치킨',2),(59,38,'모듬초밥',2),(60,39,'모듬초밥',3),(61,40,'돈까스도시락',2),(62,40,'제육도시락',1),(63,41,'치킨덮밥',3),(64,41,'비빔밥세트',2),(65,42,'연어덮밥',3),(66,42,'소코아카레',2),(67,43,'소코아카레',1),(68,43,'연어냉우동',3),(69,44,'소고기 쌀국수',3),(70,45,'소고기 쌀국수',2),(71,46,'떡튀순세트',3),(72,46,'계란찜',4),(73,47,'통큰오짱떡복이',1),(74,48,'불향차돌떡볶이',1),(75,50,'프리미엄 도시락',1),(76,51,'명란주먹밥',2),(78,53,'통큰오짱떡복이',1),(79,54,'불향차돌떡볶이',1),(80,55,'양념갈비',2),(82,57,'오징어튀김',1),(83,58,'바지락볶음',1),(84,59,'차돌부대찌개',2),(85,60,'공룡부대찌개',1),(86,61,'링귀니스파이시파스타',1),(87,62,'링귀니스파이시파스타',1),(89,64,'오징어튀김',1),(90,65,'바지락볶음',1),(91,66,'차돌부대찌개',2),(92,67,'공룡부대찌개',1),(93,68,'링귀니스파이시파스타',1),(94,69,'링귀니스파이시파스타',1),(96,71,'마늘보쌈',1),(97,72,'산낙지한상차림',1),(98,73,'콩물국수',2),(100,75,'마늘보쌈',2),(101,76,'산낙지한상차림',1),(102,77,'잔치국수',1),(104,79,'햄치즈토스트',1),(105,79,'떡갈비토스트',2),(106,80,'햄스폐셜토스트',3),(107,80,'치킨토스트',2),(108,81,'햄스페셜토스트',3),(109,81,'불닭토스트',3),(110,82,'기본수제비',3),(111,83,'떡볶이',2),(112,83,'김밥',3),(113,84,'간짜장',3),(114,85,'짬뽕',2),(115,85,'간짜장',3),(127,93,'햄스폐셜토스트',3),(128,93,'치킨토스트',2),(129,94,'햄스폐셜토스트',4),(130,94,'치킨토스트',2),(131,95,'손수제비',2),(132,96,'손수제비',3),(133,96,'김치볶음밥',3),(134,97,'떡볶이',3),(135,98,'라볶이',3),(136,99,'김치볶음밥',4),(137,100,'간짜장',4),(138,100,'볶음밥',3),(139,101,'간짜장',4),(140,101,'짬뽕',4);
/*!40000 ALTER TABLE `ordermenu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:59:57
