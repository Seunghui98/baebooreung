-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7c207.p.ssafy.io    Database: 93pro
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `special_key` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `grade` varchar(45) COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `phone` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `region` int DEFAULT NULL,
  `profile` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `route_id` int DEFAULT NULL,
  `delivery_id` int DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `encrypted_pwd` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `work_status` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  `fcm_token` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`),
  UNIQUE KEY `UK_o3v87p42ujf6nvpxi8lmbq99s` (`encrypted_pwd`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'9023ceb2-d7ba-47cb-88ab-a1d5bbe70886','DRIVER','나장엽','010-4670-5324',1,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/1/60e5403c-1c4d-4831-a500-2838596b7d2a.jfif',52,320,'sky99124@naver.com','$2a$10$rXcZ18.9rnEVY29wgUw.PeFo7U4QKSB9muIbgGLVeCcblpt1mQP7a','DRIVING','fm41UcgRSJWqtTwTM8PhoO:APA91bGkTHZyOmGTjvxVA1j5kUFxPh5lyg7vuPEbhW8pjeaxETMhUeeb1-HcvC07EGKQ_AyBOoxIrpUHd2gDXy7KVxJHPTLMXZ4oaX4NIJlreytc-y87fLuCuM6ZWjII4mU-3lrI8k2R'),(2,'b26d3426-e993-4e62-99bb-48d4d6aad515','DRIVER','김지수','010-4684-5674',34,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/2/5bedbd06-9c3d-49b5-8ebe-b9969b9ccbe5.jfif',66,394,'lgeun123@test.com','$2a$10$rOsSMfUSaK.qC2u6TfS5NOq37CuhHIdnyRst1BE.ehRSSkArz323m','DRIVING','d3ni4wHWTvyEWwqrs6ypyV:APA91bE0WCyn5rNwTDttg29SVu21GaMnUEFZytTfGPHB4a8IKKRozGrHki4GNN7koG-Zw0FTyYbha2aP0VBuNUu49J2xxod_vTtcgGF2bEVMxRpMv-qCiIGw9tJ9w4x34UsMTs40UzNb'),(3,'5d8fc1b9-08ef-4d3e-ab2a-75ca9100a848','DRIVER','이승희','010-3984-4256',34,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/3/8658ae82-da3b-41e3-8c73-83e063f12e1a.jpg',NULL,NULL,'lgeun12341@test.com','$2a$10$twE79VEC81lTEil4RG/mGu05zshqh8UDuk/pF8yjCkAeD9H1ncXQW','OFF','fm41UcgRSJWqtTwTM8PhoO:APA91bGkTHZyOmGTjvxVA1j5kUFxPh5lyg7vuPEbhW8pjeaxETMhUeeb1-HcvC07EGKQ_AyBOoxIrpUHd2gDXy7KVxJHPTLMXZ4oaX4NIJlreytc-y87fLuCuM6ZWjII4mU-3lrI8k2R'),(4,'dc10c63c-bda7-4205-b9d1-6e30b6807cda','DRIVER','안다슬','010-1274-1343',1,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/4/de5db436-9faf-4d02-b1a4-971408569cb1.jpg',7,48,'kaydenna92@gmail.com','$2a$10$yhhB8D6p8i.pArXa4wrBoOTctEaVm82Enl2j0YSoQ4W/OSFGoYgny','DRIVING',NULL),(5,'39fa0575-fed8-4f76-a9dd-771c18272d0b','DRIVER','이지은','010-8573-9567',34,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/5/4a714afe-89d5-4ecd-842f-14f6b5eb946c.jfif',73,458,'dd@test.com','$2a$10$TGm91L.sza5xnzlsOMrCMuGFvzVQ8itMuectwGs2TywHXIXvhmOGC','DRIVING','fm41UcgRSJWqtTwTM8PhoO:APA91bGkTHZyOmGTjvxVA1j5kUFxPh5lyg7vuPEbhW8pjeaxETMhUeeb1-HcvC07EGKQ_AyBOoxIrpUHd2gDXy7KVxJHPTLMXZ4oaX4NIJlreytc-y87fLuCuM6ZWjII4mU-3lrI8k2R'),(6,'ae828e26-e91e-40c1-94e2-1596b6cf86e5','MANAGER','이준호','010-5783-5738',34,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/6/51fdc8a4-eb09-4979-b196-bf8ff0035356.jpg',NULL,NULL,'ee@test.com','$2a$10$2nDwOowHoZadLyX4IRpkJOQwR1tE0bKkhMphUyACAVqqY4lOAojsG','DRIVING','fm41UcgRSJWqtTwTM8PhoO:APA91bGkTHZyOmGTjvxVA1j5kUFxPh5lyg7vuPEbhW8pjeaxETMhUeeb1-HcvC07EGKQ_AyBOoxIrpUHd2gDXy7KVxJHPTLMXZ4oaX4NIJlreytc-y87fLuCuM6ZWjII4mU-3lrI8k2R'),(8,'1d4e80ca-f52f-46cc-81f3-c0c899774bb3','DRIVER','나한나','010-3749-8457',34,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/8/6b60a939-4e89-47fc-9f72-4830f93345b6.jfif',0,0,'pass@test.com','$2a$10$QysnDLYgX6.kzUZd1XZsbOHiyy5Lbb/n/Kgfumvxp.QV9boDgw9LG','OFF','d3ni4wHWTvyEWwqrs6ypyV:APA91bE0WCyn5rNwTDttg29SVu21GaMnUEFZytTfGPHB4a8IKKRozGrHki4GNN7koG-Zw0FTyYbha2aP0VBuNUu49J2xxod_vTtcgGF2bEVMxRpMv-qCiIGw9tJ9w4x34UsMTs40UzNb'),(14,'f5806abf-984b-4f04-a6c2-eba662021470','MANAGER','김채은','010-4749-5383',9,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/14/7f6ab830-d225-4fa0-95ed-cf1500b45d18.jfif',NULL,NULL,'gugu@gaga.com','$2a$10$FzNQyJ.bUlwh3WjLEy3tjOloR.VBuL0hQLMdSld.8ftXKzrcyEEp2','DRIVING',NULL),(15,'d3d2ee6b-cd49-46a7-8103-ad27663858c3','DRIVER','한기정','010-7847-7384',9,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/15/2b327d92-8dfd-4fba-af05-bb7f60e61fe2.jfif',NULL,NULL,'gaga@gaga.com','$2a$10$7ofxiKSGYbdo03fWLmPawuLGwhVszuUTKPnKHeUgsvx9kSJQC2p7O','OFF','d3ni4wHWTvyEWwqrs6ypyV:APA91bE0WCyn5rNwTDttg29SVu21GaMnUEFZytTfGPHB4a8IKKRozGrHki4GNN7koG-Zw0FTyYbha2aP0VBuNUu49J2xxod_vTtcgGF2bEVMxRpMv-qCiIGw9tJ9w4x34UsMTs40UzNb'),(16,'179e4e5e-aaa4-492f-b27a-5458ba0b2616','DRIVER','강수지','010-9473-3736',1,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/16/a657d1a7-002c-462d-b7e2-400ae41be0c0.jfif',13,10,'hey@gaga.com','$2a$10$snLVDOb1/EO7wO7CXFVyK.5LgMVN0keIsm0id1d/WrLuZgvqI4AqG','DRIVING',NULL),(17,'aec726e2-3311-4756-92b2-1ffde8b92b9a','DRIVER','김장훈','010-2398-1729',1,'https://baebooreung.s3.ap-northeast-2.amazonaws.com/profile/17/a80efde5-4f7e-4e53-9ec4-be0a81a3740d.jfif',0,0,'jangyeop@test.com','$2a$10$9MnkpVq2tmtq2eyGQytarOFxlWupql8jneVgxyuB74kL3DGcU2sSS','OFF','d3ni4wHWTvyEWwqrs6ypyV:APA91bE0WCyn5rNwTDttg29SVu21GaMnUEFZytTfGPHB4a8IKKRozGrHki4GNN7koG-Zw0FTyYbha2aP0VBuNUu49J2xxod_vTtcgGF2bEVMxRpMv-qCiIGw9tJ9w4x34UsMTs40UzNb');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-21  0:00:25
